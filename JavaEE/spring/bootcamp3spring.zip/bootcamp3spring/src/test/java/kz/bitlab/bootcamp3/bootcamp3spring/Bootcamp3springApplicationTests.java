package kz.bitlab.bootcamp3.bootcamp3spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bootcamp3springApplicationTests {

	@Test
	void contextLoads() {
	}

}
