package kz.bitlab.bootcamp3.bootcamp3spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bootcamp3springApplication {

	public static void main(String[] args) {
		SpringApplication.run(Bootcamp3springApplication.class, args);
	}

}
